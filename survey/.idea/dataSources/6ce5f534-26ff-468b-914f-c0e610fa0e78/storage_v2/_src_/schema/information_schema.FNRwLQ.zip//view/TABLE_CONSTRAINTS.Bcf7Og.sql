create view TABLE_CONSTRAINTS as
select (`cat`.`name` collate utf8_tolower_ci)                      AS `CONSTRAINT_CATALOG`,
       (`sch`.`name` collate utf8_tolower_ci)                      AS `CONSTRAINT_SCHEMA`,
       `idx`.`name`                                                AS `CONSTRAINT_NAME`,
       (`sch`.`name` collate utf8_tolower_ci)                      AS `TABLE_SCHEMA`,
       (`tbl`.`name` collate utf8_tolower_ci)                      AS `TABLE_NAME`,
       if((`idx`.`type` = 'PRIMARY'), 'PRIMARY KEY', `idx`.`type`) AS `CONSTRAINT_TYPE`,
       'YES'                                                       AS `ENFORCED`
from (((`mysql`.`indexes` `idx` join `mysql`.`tables` `tbl` on ((`idx`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch` on ((`tbl`.`schema_id` = `sch`.`id`)))
         join `mysql`.`catalogs` `cat`
              on (((`cat`.`id` = `sch`.`catalog_id`) and (`idx`.`type` in ('PRIMARY', 'UNIQUE')))))
where ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) and
       (0 <> is_visible_dd_object(`tbl`.`hidden`, `idx`.`hidden`)))
union
select (`cat`.`name` collate utf8_tolower_ci) AS `CONSTRAINT_CATALOG`,
       (`sch`.`name` collate utf8_tolower_ci) AS `CONSTRAINT_SCHEMA`,
       (`fk`.`name` collate utf8_tolower_ci)  AS `CONSTRAINT_NAME`,
       (`sch`.`name` collate utf8_tolower_ci) AS `TABLE_SCHEMA`,
       (`tbl`.`name` collate utf8_tolower_ci) AS `TABLE_NAME`,
       'FOREIGN KEY'                          AS `CONSTRAINT_TYPE`,
       'YES'                                  AS `ENFORCED`
from (((`mysql`.`foreign_keys` `fk` join `mysql`.`tables` `tbl` on ((`fk`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch` on ((`tbl`.`schema_id` = `sch`.`id`)))
         join `mysql`.`catalogs` `cat` on ((`cat`.`id` = `sch`.`catalog_id`)))
where ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) and (0 <> is_visible_dd_object(`tbl`.`hidden`)))
union
select (`cat`.`name` collate utf8_tolower_ci) AS `CONSTRAINT_CATALOG`,
       (`sch`.`name` collate utf8_tolower_ci) AS `CONSTRAINT_SCHEMA`,
       `cc`.`name`                            AS `CONSTRAINT_NAME`,
       (`sch`.`name` collate utf8_tolower_ci) AS `TABLE_SCHEMA`,
       (`tbl`.`name` collate utf8_tolower_ci) AS `TABLE_NAME`,
       'CHECK'                                AS `CONSTRAINT_TYPE`,
       `cc`.`enforced`                        AS `ENFORCED`
from (((`mysql`.`check_constraints` `cc` join `mysql`.`tables` `tbl` on ((`cc`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch` on ((`tbl`.`schema_id` = `sch`.`id`)))
         join `mysql`.`catalogs` `cat` on ((`cat`.`id` = `sch`.`catalog_id`)))
where ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) and (0 <> is_visible_dd_object(`tbl`.`hidden`)));

